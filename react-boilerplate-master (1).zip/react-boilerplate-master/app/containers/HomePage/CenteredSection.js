import Section from './Section';

const CenteredSection = Section.extend`
  text-align: center;
`;

export default CenteredSection;
