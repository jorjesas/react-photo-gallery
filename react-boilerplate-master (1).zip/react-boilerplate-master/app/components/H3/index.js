import React from 'react';

function H3(props) {
  return (
    <h3 {...props} />
  );
}

export default H3;
